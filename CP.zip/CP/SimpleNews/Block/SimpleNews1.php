<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace CP\SimpleNews\Block;

use Magento\Framework\View\Element\Template;

/**
 * Main contact form block
 */
class SimpleNews extends Template{


    public function getEditUrl() {
    	echo "string"; exit();

    }

}