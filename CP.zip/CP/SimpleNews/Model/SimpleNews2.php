<?php
namespace CP\SimpleNews\Model;
class SimpleNews2 extends \Magento\Framework\Model\AbstractModel
{
    protected function _construct()
    {
		// $this->_init('CP\SimpleNews\Model\ResourceModel\SimpleNews');
		$this->_init('CP\SimpleNews\Model\ResourceModel\SimpleNews2');

    }
}

