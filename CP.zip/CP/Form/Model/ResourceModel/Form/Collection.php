<?php
namespace CP\Form\Model\ResourceModel\Form;



class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'id';
    protected function _construct()
    {
		$this->_init('CP\Form\Model\Form','CP\Form\Model\ResourceModel\Form');
    }
}