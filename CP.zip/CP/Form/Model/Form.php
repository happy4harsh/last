<?php
namespace CP\Form\Model;
class Form extends \Magento\Framework\Model\AbstractModel
{
    protected function _construct()
    {
		$this->_init('CP\Form\Model\ResourceModel\Form');
    }
}

