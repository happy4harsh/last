<?php
/**
*
* Copyright © 2016 Magento. All rights reserved.
*/
namespace CP\Form\Controller\Index;
use Magento\Framework\Controller\ResultFactory;
use CP\Form\Model\EmployeeFactory;
use CP\Form\Model\ResourceModel\Employee\CollectionFactory;
class Post extends \Magento\Framework\App\Action\Action
{                                                          
    protected $resultPageFactory;
    protected $appointmentModel;
    protected $_messageManager;
    protected $collectionFactory;
   
    public function __construct(\Magento\Framework\App\Action\Context $context, 
       \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        EmployeeFactory $appointmentModel,
        CollectionFactory $collectionFactory,  
        \Magento\Framework\Message\ManagerInterface $messageManager
   

        )
    {
       
        $this->resultPageFactory = $resultPageFactory;
        $this->appointmentModel = $appointmentModel;
        $this->collectionFactory = $collectionFactory;
        $this->_messageManager = $messageManager;
       
        parent::__construct($context);
    }

public function execute(){
        $post = $this->getRequest()->getPostValue();
        
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();  

        $fileSystem = $objectManager->create('\Magento\Framework\Filesystem');
        
        $mediaPath=$fileSystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)->getAbsolutePath().'customring/';

        if (count($_FILES["image"]) > 0)
        {

            $folderName = $mediaPath;
            
            $counter = 0;
            $imageArray = array();

            for ($i = 0; $i < count($_FILES["image"]["name"]); $i++)
            {
                if ($_FILES["image"]["name"][$i] <> "")
                {
                    $tmp = explode('.', $_FILES["image"]["name"][$i]);
                    $ext = end($tmp);
                    $imageName = rand(10000, 990000) . '_' . time() . '.' . $ext;
                    $imageArray[] = $imageName;
                    $filePath = $folderName . $imageName;

                    if (!move_uploaded_file($_FILES["image"]["tmp_name"][$i], $filePath))
                    {
                        $msg .= "Failed to upload" . $_FILES["image"]["name"][$i] . ". <br>";
                        $counter++;
                    }
                }
            }
        }

        //print_r($imageArray); die;
        
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        
        if (!$post) {
            $this->_redirect('');
            return;
        }



///exception catched here by zend ////
try {
$postObject = new \Magento\Framework\DataObject();
$postObject->setData($post);

$error = false;

if (!\Zend_Validate::is(trim($post['name']), 'NotEmpty')) {
$error = true;

}

// if (!\Zend_Validate::is(trim($post['description']), 'NotEmpty')) {
// $error = true;
// }


if ($error) {
throw new \Exception();
}
//data saved if no error////
        // echo "<pre>";print_r($post);exit;
        $post['image'] = implode(',', $imageArray);
        
         $model = $this->appointmentModel->create();
         $model->setname($post['name'])
        ->setcity($post['city'])
        ->setdate(date('Y-m-d',strtotime($post['calendar_inputField'])))
        ->setstatus($post['status'])
        ->setImage($post['image'])
              ->save();
                  

       // $this->_messageManager->addSuccess("savesd.");
       // return $resultRedirect;
///Succes
            $this->messageManager->addSuccess(
            __('Thanks for contacting us with your comments and questions.')
            );
            $this->_redirect('form/index/index');
            return;
            }
            //// catching exception ////
            catch (\Exception $e) {
                $this->messageManager->addError(
                __('We can\'t process your request right now. Sorry, that\'s all we know.')
                );
                $this->_redirect('form/index/index');
                return;
            }

    }

}
?>