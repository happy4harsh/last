<?php
 
namespace CP\Override\Controller\Index;
 
 
class Display extends \Magento\Framework\App\Action\Action
{
  
 
    public function execute()
    {
                 
         $this->_view->loadLayout();
        $this->_view->getLayout()->getBlock('display');
        $this->_view->renderLayout();
    }
}