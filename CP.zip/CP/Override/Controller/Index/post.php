<?php
/**
*
* Copyright © 2016 Magento. All rights reserved.
*/
namespace CP\Override\Controller\Index;
use Magento\Framework\Controller\ResultFactory;
use CP\Override\Model\OverrideFactory;
use CP\Override\Model\ResourceModel\Override\CollectionFactory;
class post extends \Magento\Framework\App\Action\Action
{                                                          
    protected $resultPageFactory;
    protected $appointmentModel;
    protected $_messageManager;
    protected $collectionFactory;
   
    public function __construct(\Magento\Framework\App\Action\Context $context, 
       \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        OverrideFactory $appointmentModel,
        CollectionFactory $collectionFactory,  
        \Magento\Framework\Message\ManagerInterface $messageManager
   

        )
    {
       
        $this->resultPageFactory = $resultPageFactory;
        $this->appointmentModel = $appointmentModel;
        $this->collectionFactory = $collectionFactory;
        $this->_messageManager = $messageManager;
       
        parent::__construct($context);
    }

public function execute(){
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        $post = $this->getRequest()->getPostValue();
        
        if (!$post) {
            $this->_redirect('');
            return;
        }

///exception catched here by zend ////
try {
$postObject = new \Magento\Framework\DataObject();
$postObject->setData($post);

$error = false;

if (!\Zend_Validate::is(trim($post['name']), 'NotEmpty')) {
$error = true;
}

if (!\Zend_Validate::is(trim($post['description']), 'NotEmpty')) {
$error = true;
}


if ($error) {
throw new \Exception();
}
//data saved if no error////
 		// echo "<pre>";print_r($post);exit;
        
         $model = $this->appointmentModel->create();
         $model->setname($post['name'])
        ->setdescription($post['description'])
        ->setcreated_at(date('Y-m-d',strtotime($post['calendar_inputField'])))
        ->setstatus($post['status'])
              ->save();
                  

       // $this->_messageManager->addSuccess("savesd.");
       // return $resultRedirect;
///Succes
			// $this->messageManager->addSuccess(
			// __('Your Data is Saved Succesfully.')
			// );
			$this->_redirect('newsmodule/index/display');
			return;
			}
			//// catching exception ////
			catch (\Exception $e) {
				$this->messageManager->addError(
				__('We can\'t process your request right now. Sorry, that\'s all we know.')
				);
				$this->_redirect('newsmodule/index/index');
				return;
			}

    }

}
?>