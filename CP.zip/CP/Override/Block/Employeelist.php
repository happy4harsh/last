<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace CP\Override\Block;

use Magento\Framework\View\Element\Template;

/**
 * Main contact form block
 */
class Employeelist extends Template
{
    /**
     * @param Template\Context $context
     * @param array $data
     */
    protected $_overrideFactory;
    protected $_storeManager;
    protected $_scopeConfig;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \CP\Override\Model\OverrideFactory $overrideFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        array $data = []
     ) 
    {
        $this->_overrideFactory = $overrideFactory;
        $this->_storeManager = $storeManager;
        $this->_scopeConfig = $scopeConfig;
        parent::__construct($context, $data);
        //get collection of data 
        $collection = $this->_overrideFactory->create()->getCollection();
        $this->setCollection($collection);
        $this->pageConfig->getTitle()->set(__('Commerce Pundit List'));
    }

    protected function _prepareLayout()
    {
        parent::_prepareLayout();
        if ($this->getCollection()) {
            // create pager block for collection 
            $pager = $this->getLayout()->createBlock(
                'Magento\Theme\Block\Html\Pager',
                'cp.override.record.pager'
            )->setCollection(
                $this->getCollection() // assign collection to pager
            );
            $this->setChild('pager', $pager);// set pager block in layout
        }
        return $this;
    }
  
    /**
     * @return string
     */
    // method for get pager html
    public function getPagerHtml()
    {
        return $this->getChildHtml('pager');
    } 

    public function getBaseUrl()
    {
    return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_LINK);
    }
   public function getDeleteUrl($newsid) {
            return $this->getUrl('newsmodule/index/delete', array('newsid' => $newsid));
        }

 public function getEditUrl($newsid) {
            return $this->getUrl('newsmodule/index/index', array('newsid' => $newsid));
        }
    public function getConfigUrl()
    {
        $ConfigUrl =  $this->_scopeConfig->getValue('web/unsecure/base_url', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        return $ConfigUrl;
    }
    /*public function __construct(Template\Context $context, array $data = [])
    {
        parent::__construct($context, $data);
        $this->_isScopePrivate = true;
    }*/
}
