<?php
namespace CP\Override\Block;
  
class news1 extends \Magento\Framework\View\Element\Template
{
    public function getFormAction()
    {
    	
        echo "block3";exit();
    }
}