<?php
namespace CP\Override\Model\ResourceModel\Override;



class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'id';
    protected function _construct()
    {
		$this->_init('CP\Override\Model\Override','CP\Override\Model\ResourceModel\Override');
    }
}