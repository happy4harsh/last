<?php
  
namespace CP\News\Model;
  
use Magento\Framework\Model\AbstractModel;
  
class News extends AbstractModel
{
    /**
     * Define resource model
     */
    protected function _construct()
    {
        $this->_init('CP\News\Model\ResourceModel\News');
    }
}
