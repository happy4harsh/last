<?php              
namespace CP\News\Controller\Index;
use Magento\Framework\Controller\ResultFactory;
use CP\News\Model\NewsFactory;
use CP\News\Model\ResourceModel\News\CollectionFactory;
class Save extends \Magento\Framework\App\Action\Action
{                                                          
    protected $resultPageFactory;
    protected $NewsModel;   
    protected $collectionFactory;
    
    public function __construct(\Magento\Framework\App\Action\Context $context, 
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        NewsFactory $newsModel,
        CollectionFactory $collectionFactory  
       
        )
    {
        $this->resultPageFactory = $resultPageFactory;
        $this->newsModel = $newsModel;
        $this->collectionFactory = $collectionFactory;
        parent::__construct($context);
    }
    public function execute()
    {
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        $post = $this->getRequest()->getPostValue();
        
        if (!$post) {
            $this->_redirect('');
            return;
        }
       //echo "<pre>";print_r($post);exit;
        $model = $this->newsModel->create();
        if($this->getRequest()->getParam('id')){
            $model->load($this->getRequest()->getParam('id'));
        }
        $model->setname($post['name'])
              ->setcreated_date($post['dt'])
              ->setdescription($post['des'])
              ->setstatus($post['status'])
              ->save();

        $this->_redirect('*/*/post/');
       //return $resultRedirect;
    }
}
?>
