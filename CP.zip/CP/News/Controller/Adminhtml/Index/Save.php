<?php
namespace CP\News\Controller\Adminhtml\Index;
use Magento\Framework\App\Filesystem\DirectoryList;

use Magento\Backend\App\Action;
use Magento\TestFramework\ErrorLog\Logger;

class Save extends \Magento\Backend\App\Action
{
    protected $cacheTypeList;
    protected $jsHelper;

    const ADMIN_RESOURCE = 'CP_News::save';
    protected $adapterFactory;
    protected $uploader;
    protected $filesystem;


    protected $_filesystem;
    protected $_storeManager;
    protected $_directory;
    protected $_imageFactory;

    public function __construct(
        Action\Context $context,
        \Magento\Framework\App\Cache\TypeListInterface $cacheTypeList,
        \Magento\Backend\Helper\Js $jsHelper,
        \Magento\Framework\Image\AdapterFactory $adapterFactory,
        \Magento\MediaStorage\Model\File\UploaderFactory $uploader,        

        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Framework\Image\AdapterFactory $imageFactory
    )
    {        
        $this->_storeManager = $storeManager;
        $this->_directory = $filesystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        $this->_imageFactory = $imageFactory;

        $this->adapterFactory = $adapterFactory;
        $this->uploader = $uploader;
        $this->filesystem = $filesystem;
        $this->cacheTypeList = $cacheTypeList;
        parent::__construct($context);
        $this->jsHelper = $jsHelper;
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed(self::ADMIN_RESOURCE);
    }

    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        
        
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($data) 
        {
            
            $model = $this->_objectManager->create('CP\News\Model\News');

            $id = $this->getRequest()->getParam('id');
            if ($id) {
                $model->load($id);
            }

            $model->setData($data);

            try {
                $model->save();

                $this->cacheTypeList->invalidate('full_page');
                $this->messageManager->addSuccess(__('You saved this News.'));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['id' => $model->getId(), '_current' => true]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the Event.'));
            }

            //$this->_getSession()->setFormData($data);
            return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }

    // public function imageResize($image, $width = null, $height = null,$absPath,$resizepath)
    // {

    //     $absPath = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath($absPath).$image;;
    //     //echo $absPath;exit;
    //     if(!file_exists($absPath)){
    //         return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).'cp/events/images/resized/noimage.jpg';
    //     }
    //     $imageResized = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath($resizepath).$image;
    //     $imageResize = $this->_imageFactory->create();         
    //     $imageResize->open($absPath);
    //     $imageResize->constrainOnly(TRUE);         
    //     $imageResize->keepTransparency(TRUE);         
    //     $imageResize->keepFrame(FALSE);         
    //     $imageResize->keepAspectRatio(TRUE);         
    //     $imageResize->resize($width,$height);  
    //     $destination = $imageResized ;    
    //     $imageResize->save($destination);         
    //     $resizedURL= $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA).$resizepath.$image;
    //     return $resizedURL;  
    // }
}