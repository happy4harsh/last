<?php
namespace CP\News\Controller\Adminhtml\Index;
use Magento\Framework\App\Action\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends \Magento\Backend\App\Action
{
    protected $resultPageFactory;

    /**
    * @param Context $context
    * @param PageFactory $resultPageFactory
    */
    public function __construct(Context $context, \Magento\Framework\Registry $coreRegistry,PageFactory $resultPageFactory) {
        parent::__construct($context, $coreRegistry);
        $this->resultPageFactory = $resultPageFactory;
    }
 

    protected function initPage($resultPage)
    {
        $resultPage->setActiveMenu('CP_News::post')
            ->addBreadcrumb(__('Show Appointment'), __('Show Appointment'))
            ->addBreadcrumb(__('Show Appointment'), __(''));
        return $resultPage;
    }

    public function execute(){
        //echo "hello";
        $resultPage = $this->resultPageFactory->create();
        $this->initPage($resultPage)->getConfig()->getTitle()->prepend(__('News'));
        return $resultPage;
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('CP_News::newscp');
    }
}
