<?php
namespace CP\News\Block;
use Magento\Framework\View\Element\Template;
class Form extends \Magento\Framework\View\Element\Template
{
    public function getHelloWorldTxt()
     	{
         	$post= $this->getRequest()->getPostValue();  	
        	return $post;
     	}
}