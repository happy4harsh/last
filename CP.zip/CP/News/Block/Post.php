<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace CP\News\Block;

use Magento\Framework\View\Element\Template;

/**
 * Main contact form block
 */
class Post extends Template{

    protected $_newsFactory; 

     public function __construct(Template\Context $context,
        \CP\News\Helper\Data $helper,
        \CP\News\Model\NewsFactory $eventsFactory,
        \Magento\Framework\App\Request\Http $request,
         array $data = [])
    {
        $this->helper = $helper;
        $this->_newsFactory = $eventsFactory;
        $this->request = $request;
        parent::__construct($context, $data);
    } 

    public function getFormAction(){
        if($this->getRequest()->getParam('id')){
            return $this->getUrl('news/index/save/id/'.$this->getRequest()->getParam('id'));    
        } else {
            return $this->getUrl('news/index/save');
        }
        return $this->getUrl('news/index/save');
    }
    public function getCollection()
    {
        $id=$this->getRequest()->getParam('id') ;// all params
        $post = $this->_newsFactory->create()->load($id);
        return $post;
    }
    public function getnewscollection()
    {
        $data=$this->_newsFactory->create()->getCollection();
        return $data;
    }
    public function getDeleteUrl($id) {
            return $this->getUrl('news/index/delete', array('id' => $id));
        }
    public function getEditUrl($id) {
        return $this->getUrl('news/index/newaction', array('id' => $id));
    }

}