var config = {
    paths: {            
            'bxslider': "Magento_CatalogWidget/js/jquery.bxslider.min"
        },   
    shim: {
        'bxslider': {
            deps: ['jquery']
        }
    }
};
