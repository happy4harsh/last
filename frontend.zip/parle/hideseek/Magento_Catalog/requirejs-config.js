var config = {
    paths: {            
            'bxslider': "Magento_Catalog/js/jquery.bxslider.min"
        },   
    shim: {
        'bxslider': {
            deps: ['jquery']
        }
    }
};