<?php
/**
 * @copyright Copyright (c) 2016 www.magebuzz.com
 */
namespace CP\Categoryattribute\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\ResultFactory;
use Magento\Catalog\Api\ProductRepositoryInterface;

class Addcart extends Action
{
    protected $_resultPageFactory;

    public function __construct(
        Context $context, 
        \Magento\Catalog\Model\Product $productFactory,
        \Magento\Checkout\Model\Cart $cart,
        \Magento\Catalog\Model\ProductRepository $productRepository,
        PageFactory $resultPageFactory
        )
    {
       parent::__construct($context);
       $this->productFactory = $productFactory;
       $this->cart = $cart;
       $this->_resultPageFactory = $resultPageFactory;
       $this->_productRepository = $productRepository;
    }


    public function execute()
    {
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $categoryId = $this->getRequest()->getParam('id');
        $_objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $object_manager = $_objectManager->create('Magento\Catalog\Model\Category')->load($categoryId);
        $cpsku = $object_manager->getCpSkuAtrribute();
        $products = explode(",",$cpsku);
        try{
            foreach($products as $sku)
            {
                $product = $this->_productRepository->get($sku);
                $params = array();
                $params['product'] = $product->getId();
                $params['qty'] = '1';//product quantity

                if ($product) {
                    $this->cart->addProduct($product->getId(), $params);
                }
            }
        $this->cart->getQuote()->setTotalsCollectedFlag(false);
        $this->cart->save();
        if (!$this->cart->getQuote()->getHasError()) {
            $message = __(
            'Items added to your shopping cart.'
            );
            $this->messageManager->addSuccessMessage($message);
        }
        $this->_redirect($this->_redirect->getRefererUrl());

        }catch(\Exception $e){
            die($e->getMessage());
        }


        // $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        
        // return $resultRedirect;
    }
}