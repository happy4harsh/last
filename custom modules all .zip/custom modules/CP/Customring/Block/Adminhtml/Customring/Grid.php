<?php
namespace CP\Customring\Block\Adminhtml\Customring;

class Grid extends \Magento\Backend\Block\Widget\Grid\Extended
{
    /**
     * @var \Magento\Framework\Module\Manager
     */
    protected $moduleManager;

    /**
     * @var \CP\Customring\Model\customringFactory
     */
    protected $_customringFactory;

    /**
     * @var \CP\Customring\Model\Status
     */
    protected $_status;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Backend\Helper\Data $backendHelper
     * @param \CP\Customring\Model\customringFactory $customringFactory
     * @param \CP\Customring\Model\Status $status
     * @param \Magento\Framework\Module\Manager $moduleManager
     * @param array $data
     *
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Backend\Helper\Data $backendHelper,
        \CP\Customring\Model\CustomringFactory $CustomringFactory,
        \CP\Customring\Model\Status $status,
        \Magento\Framework\Module\Manager $moduleManager,
        array $data = []
    ) {
        $this->_customringFactory = $CustomringFactory;
        $this->_status = $status;
        $this->moduleManager = $moduleManager;
        parent::__construct($context, $backendHelper, $data);
    }

    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('postGrid');
        $this->setDefaultSort('customring_id');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);
        $this->setUseAjax(false);
        $this->setVarNameFilter('post_filter');
    }

    /**
     * @return $this
     */
    protected function _prepareCollection()
    {
        $collection = $this->_customringFactory->create()->getCollection();
        $this->setCollection($collection);

        parent::_prepareCollection();

        return $this;
    }

    /**
     * @return $this
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareColumns()
    {
        $this->addColumn(
            'customring_id',
            [
                'header' => __('ID'),
                'type' => 'number',
                'index' => 'customring_id',
                'header_css_class' => 'col-id',
                'column_css_class' => 'col-id'
            ]
        );


		
				$this->addColumn(
					'name',
					[
						'header' => __('Name'),
						'index' => 'name',
					]
				);
				
				$this->addColumn(
					'phone_number',
					[
						'header' => __('Phone Number'),
						'index' => 'phone_number',
					]
				);
				
				$this->addColumn(
					'email_id',
					[
						'header' => __('Email'),
						'index' => 'email_id',
					]
				);
				
				$this->addColumn(
                    'shape',
                    [
                        'header' => __('Shape'),
                        'index' => 'shape',
                        'type' => 'options',
                        'options' => \CP\Customring\Block\Adminhtml\Customring\Grid::getOptionArray1()
                    ]
                );
				
				$this->addColumn(
                    'metal',
                    [
                        'header' => __('Metal'),
                        'index' => 'metal',
                        'type' => 'options',
                        'options' => \CP\Customring\Block\Adminhtml\Customring\Grid::getOptionArray0()
                    ]
                );

                $this->addColumn(
                    'ring_size',
                    [
                        'header' => __('Ring Size'),
                        'index' => 'ring_size',
                        'type' => 'options',
                        'options' => \CP\Customring\Block\Adminhtml\Customring\Grid::getOptionArray2()
                    ]
                );
				
				/*$this->addColumn(
					'description',
					[
						'header' => __('Description'),
						'index' => 'description',
					]
				);*/

                
				


		
        //$this->addColumn(
            //'edit',
            //[
                //'header' => __('Edit'),
                //'type' => 'action',
                //'getter' => 'getId',
                //'actions' => [
                    //[
                        //'caption' => __('Edit'),
                        //'url' => [
                            //'base' => '*/*/edit'
                        //],
                        //'field' => 'customring_id'
                    //]
                //],
                //'filter' => false,
                //'sortable' => false,
                //'index' => 'stores',
                //'header_css_class' => 'col-action',
                //'column_css_class' => 'col-action'
            //]
        //);
		

		
		   $this->addExportType($this->getUrl('customring/*/exportCsv', ['_current' => true]),__('CSV'));
		   $this->addExportType($this->getUrl('customring/*/exportExcel', ['_current' => true]),__('Excel XML'));

        $block = $this->getLayout()->getBlock('grid.bottom.links');
        if ($block) {
            $this->setChild('grid.bottom.links', $block);
        }

        return parent::_prepareColumns();
    }

	
    /**
     * @return $this
     */
    protected function _prepareMassaction()
    {

        $this->setMassactionIdField('customring_id');
        //$this->getMassactionBlock()->setTemplate('CP_Customring::customring/grid/massaction_extended.phtml');
        $this->getMassactionBlock()->setFormFieldName('customring');

        $this->getMassactionBlock()->addItem(
            'delete',
            [
                'label' => __('Delete'),
                'url' => $this->getUrl('customring/*/massDelete'),
                'confirm' => __('Are you sure?')
            ]
        );

        $statuses = $this->_status->getOptionArray();

        $this->getMassactionBlock()->addItem(
            'status',
            [
                'label' => __('Change status'),
                'url' => $this->getUrl('customring/*/massStatus', ['_current' => true]),
                'additional' => [
                    'visibility' => [
                        'name' => 'status',
                        'type' => 'select',
                        'class' => 'required-entry',
                        'label' => __('Status'),
                        'values' => $statuses
                    ]
                ]
            ]
        );


        return $this;
    }
		

    /**
     * @return string
     */
    public function getGridUrl()
    {
        return $this->getUrl('customring/*/index', ['_current' => true]);
    }

    /**
     * @param \CP\Customring\Model\customring|\Magento\Framework\Object $row
     * @return string
     */
    public function getRowUrl($row)
    {
		
        return $this->getUrl(
            'customring/*/edit',
            ['customring_id' => $row->getId()]
        );
		
    }

        //This option value is for Shape
        static public function getOptionArray0()
        {
            $data_array=array();
            $data_array[]=' '; 
            $data_array[0]='Gold';
            $data_array[1]='Silver';
            $data_array[2]='Platinium';
            return($data_array);
        }
        static public function getValueArray0()
        {
            $data_array=array();
            foreach(\CP\Test\Block\Adminhtml\Test\Grid::getOptionArray0() as $k=>$v){
               $data_array[]=array('value'=>$k,'label'=>$v);        
            }
            return($data_array);

        }

        //This option value is for Metal
        static public function getOptionArray1()
        {
            $data_array=array();
            $data_array[0]='Square';
            $data_array[1]='Circle';
            $data_array[2]='Triangle';
            $data_array[3]='Rectangle';
            $data_array[4]='Oval';
            return($data_array);
        }
        static public function getValueArray1()
        {
            $data_array=array();
            foreach(\CP\Test\Block\Adminhtml\Test\Grid::getOptionArray0() as $k=>$v){
               $data_array[]=array('value'=>$k,'label'=>$v);        
            }
            return($data_array);

        }


        //This option value is for Ring Size
        static public function getOptionArray2()
        {
            $data_array=array();
            for ($i=1; $i < 30; $i++) { 
                $data_array[$i] = $i;
            }

            return($data_array);
        }
        static public function getValueArray2()
        {
            $data_array=array();
            foreach(\CP\Test\Block\Adminhtml\Test\Grid::getOptionArray0() as $k=>$v){
               $data_array[]=array('value'=>$k,'label'=>$v);        
            }
            return($data_array);

        }
	

}