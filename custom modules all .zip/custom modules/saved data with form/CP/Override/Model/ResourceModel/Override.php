<?php
namespace CP\Override\Model\ResourceModel;
use \Magento\Framework\Model\ResourceModel\Db\AbstractDb;
class Override extends AbstractDb
{
    protected function _construct()
    {
        $this->_init('cp_test','id');
    }
}

