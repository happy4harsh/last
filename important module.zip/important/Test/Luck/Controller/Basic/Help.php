<?php
namespace Test\Luck\Controller\Basic;

use \Magento\Framework\App\Action\Action;
use \Magento\Framework\App\Action\Context;
use \Test\Luck\Helper\Data;

class Help extends Action
{
    var $helper;

    public function __construct(
        Context $context,
        Data $helper
    ) {
        $this->helper = $helper;
        parent::__construct($context);
    }
    public function execute()
    {
    	
       $first = "a12";
       $second = "123";

       echo "Is $first a number? " . $this->helper->isNumber($first) . "<br/>";
       echo "Is $second a number? " . $this->helper->isNumber($second) . "<br/>";
    }
}
?>