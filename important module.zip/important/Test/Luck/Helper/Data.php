<?php
namespace Test\Luck\Helper;

use \Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper{

    public function isNumber($x){
        return is_numeric($x) ? "yes" : "no";
    }
}