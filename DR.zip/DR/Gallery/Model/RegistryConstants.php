<?php
/**
 * Created by PhpStorm.
 * User: daniel
 * Date: 08.03.16
 * Time: 15:44
 */

namespace DR\Gallery\Model;


class RegistryConstants
{
    const CURRENT_GALLERY = 'current_gallery';

    const CURRENT_IMAGE = 'current_image';
}