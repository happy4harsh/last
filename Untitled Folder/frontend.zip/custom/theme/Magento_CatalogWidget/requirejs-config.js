// var config ={
// 	path : {
// 		'slick' : "Magento_CatalogWidget/js/slick"
// 	},
// 	 shim: {
//         'slick': {
//             deps: ['jquery']
//         }
// }
var config = {
    map: {
        '*': {
            'slick' : "Magento_CatalogWidget/js/slick",
        }
    }
};