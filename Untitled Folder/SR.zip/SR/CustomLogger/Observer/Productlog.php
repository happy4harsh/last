<?php

namespace SR\CustomLogger\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer as EventObserver;

class Productlog implements ObserverInterface
{

/**
 * @var \Magento\Framework\App\RequestInterface
 */
    protected $_request;
    protected $_logger;
/**
 * @param \Magento\Framework\App\RequestInterface $request
 */
    public function __construct(
        \Magento\Framework\App\RequestInterface $request,
        \SR\CustomLogger\Logger\Logger $logger
        ) {
            $this->_request = $request;
            $this->_logger = $logger;
        }


/**
 * @param EventObserver $observer
 * @return void
 */
    public function execute(EventObserver $observer)
    { 
   
           
       $reqeustParams = $this->_request->getParams();

       $this->_logger->info("Product ID-".$reqeustParams["product"]);
   
       $this->_logger->info("FormKey-".$reqeustParams["form_key"]);
   
      
   
    }


}