<?php
    /**
     * Webkul Hello CustomPrice Observer
     *
     * @category    Webkul
     * @package     Webkul_Hello
     * @author      Webkul Software Private Limited
     *
     */
    namespace CP\News\Observer;
 
    use Magento\Framework\Event\ObserverInterface;
    use Magento\Framework\App\RequestInterface;
 
    class CustomPrice implements ObserverInterface
    {
        public function execute(\Magento\Framework\Event\Observer $observer) {
            // echo "string"; exit();
            $item = $observer->getEvent()->getQuoteItem();         
            $item = ( $item->getParentItem() ? $item->getParentItem() : $item );
            $oldprice = $item->getProduct()->getFinalPrice();
            $price=$oldprice*80/100;
            $item->setCustomPrice($price);
            $item->setOriginalCustomPrice($price);
            $item->getProduct()->setIsSuperMode(true);
        }
 
    }