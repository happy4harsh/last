<?php 

namespace CP\News\Plugin;

use Magento\Framework\UrlInterface;
use Magento\Framework\Data\Tree\NodeFactory;
use Magento\Store\Model\StoreManagerInterface;

class Topmenu
{
    /**
     * @var NodeFactory
     */
    protected $nodeFactory;
    protected $urlBuilder;
    protected $_storeManager;

    public function __construct(
        UrlInterface $urlBuilder,
        NodeFactory $nodeFactory,
        StoreManagerInterface $storeManager
    ) {
        $this->urlBuilder = $urlBuilder;
        $this->nodeFactory = $nodeFactory;
        $this->_storeManager = $storeManager;
    }
    public function beforeGetHtml(
        \Magento\Theme\Block\Html\Topmenu $subject
        // $outermostClass = '',
        // $childrenWrapClass = '',
        // $limit = 0
    ) {
        $node = $this->nodeFactory->create(
            [
                'data' => $this->getNodeAsArray('Contact','contact'),
                'idField' => 'id',
                'tree' => $subject->getMenu()->getTree()
            ]
        );
        $secondNode = $this->nodeFactory->create(
            [
                'data' => $this->getNodeAsArray('Downloadable','downloadable/customer/products/'),
                'idField' => 'id',
                'tree' => $subject->getMenu()->getTree()
            ]
        );
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->get('Magento\Customer\Model\Session');
        if($customerSession->isLoggedIn()) {
            $subject->getMenu()->addChild($node);
            $subject->getMenu()->addChild($secondNode);
        }
        else{
            $subject->getMenu()->addChild($node);
            //$subject->getMenu()->addChild($secondNode);
        }
        
    }
    
    protected function getNodeAsArray($name,$id)
    {
        return [
            'name' => __($name),
            'id' => $id,
            'url' => $this->urlBuilder->getUrl($id),
            'has_active' => false,
            'target'=>"_blank",
            'is_active' => false // (expression to determine if menu item is selected or not)
        ];
    }
}