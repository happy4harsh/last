<?php 
namespace CP\News\Block\Adminhtml;
 
class News extends \Magento\Backend\Block\Widget\Grid\Container
{
    protected function _construct()
    {
        $this->_blockGroup = 'CP_News';
        $this->_controller = 'adminhtml_news';
        $this->_headerText = __('News');
        $this->_addButtonLabel = __('Add News');
        parent::_construct();
    }
}
