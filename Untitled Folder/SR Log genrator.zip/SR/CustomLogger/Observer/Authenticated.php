<?php

namespace SR\CustomLogger\Observer;

use Magento\Framework\Event\ObserverInterface;

class Authenticated implements ObserverInterface
{
    /**
     * @var \SR\CustomLogger\Logger\Logger $logger
     */
    protected $logger;

    /**
     * @param \SR\CustomLogger\Logger\Logger $logger
     */
    public function __construct(
        \SR\CustomLogger\Logger\Logger $logger
    ) {
        $this->logger = $logger;
    }

    /**
     * Upgrade customer password hash when customer has logged in
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        /** @var \Magento\Customer\Model\Customer $model */
         $model = $observer->getEvent()->getData('model');
         if($model->getId()) {
        
			
			$customerId = $model->getId();
			$customerName= $model->getName();
   			$this->logger->info("Customer ID".$customerId."Customer Name".$customerName);
         
         }
        
    }
}
