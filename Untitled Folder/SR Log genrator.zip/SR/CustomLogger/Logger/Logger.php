<?php
namespace SR\CustomLogger\Logger;


class Logger extends \Monolog\Logger
{

}