<?php
namespace CP\Coreoverride\Block;

use Magento\Framework\View\Element\Template;

class Coreoverride extends Template{
	/**
     * Preparing global layout
     *
     * @return void
     */
    protected function _prepareLayout()
    {
        parent::_prepareLayout();
        $this->pageConfig->getTitle()->set(__('My Downloads'));
    }
	public function getLink(){
		echo "Links";
		return;
	}

    public function getCollection(){
        $post = $this->getRequest()->getPostValue();
        $TextSku= $post["sku"];

        // $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        // $product = $objectManager->get('Magento\Framework\Registry')->registry('current_product');//get current product
        // $productTypeInstance = $product->getTypeInstance();
        // $usedProducts = $productTypeInstance->getUsedProducts($product);

        // echo $product->getId(); //Main configurable product ID
        // echo $product->getName(); //Main Configurable Name

        // foreach ($usedProducts  as $child) {
        // echo $child->getId()."</br>"; //Child Product Id  
        // echo $child->getName()."</br>"; //Child Product Name
    }
    
}