<?php
namespace CP\Coreoverride\Block;
class Helloworld extends \Magento\Framework\View\Element\Template
{    
    protected $_stockItemRepository;

  protected $_productloader;  

        
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,        
        \Magento\CatalogInventory\Model\Stock\StockItemRepository $stockItemRepository,
        \Magento\Catalog\Model\ProductFactory $_productloader,
        array $data = []
    )
    {
        $this->_stockItemRepository = $stockItemRepository;
                $this->_productloader = $_productloader;
        parent::__construct($context, $data);
    }
    
    public function getStockItem($productId)
    {
        return $this->_stockItemRepository->get($productId);
    }
     public function getLoadProduct($id)
    {
        return $this->_productloader->create()->load($id);
    }
}
?>