<?php
namespace CP\Coreoverride\Controller\Index;
 
 
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
 
class AddProducttocart extends \Magento\Customer\Controller\AbstractAccount
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;
    /**
     * @var \Magento\Framework\Data\Form\FormKey
     */
    protected $formKey;
    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        \Magento\Framework\Data\Form\FormKey $formKey,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->formKey = $formKey;
        $this->resultPageFactory = $resultPageFactory;
    }
 
    /**
     *
     * @return \Magento\Framework\View\Result\Page
     */
    public function execute()
    {
      
        $addtocart=$this->getRequest()->getParam('addtocart');
        $addtocart1=$this->getRequest()->getParam('addtocart1');
        $addtocart2=$this->getRequest()->getParam('addtocart2');
        // Adding Value of Cart One
        if($addtocart)
        {  
            $sku = $this->getRequest()->getParam('sku');
            $qty = $this->getRequest()->getParam('qty');
            $price = $this->getRequest()->getParam('price');
           if($price)
            {
                $checkqty=$this->getRequest()->getParam('checkqty');

                if($qty>$checkqty)
                {
                    print_r($qty);
                    print_r($checkqty);
                    die();
                    $this->messageManager->addWarning('Quantity Are Not Available As Per Your Need');
                    $this->_redirect("coreoverride/index/index");
                   }
                   else
                   {
                    $pid=$this->getRequest()->getParam('pid');
                    $resultPage = $this->resultPageFactory->create();
                    $params = array(
                        'form_key' => $this->formKey->getFormKey(),
                        'product' =>$pid,//product Id
                        'qty'   =>$qty,//quantity of product
                        'price' =>$price //product price
                    );
                    // echo $pid.$qty.$price;
                    // exit();
                    $this->_redirect("checkout/cart/add/form_key/", $params);
                    /* * @var \Magento\Framework\View\Result\Page $resultPage */
                    return $resultPage;
                }
            }
            else
            {
                    $this->messageManager->addWarning('Please Fill All The Values it Should Not Be 0 or Empty');
                    $this->_redirect("coreoverride/index/index");
            }
        }
// Adding Value of Cart two
        if($addtocart1)
        { 
             $sku1 = $this->getRequest()->getParam('sku1');
             $qty1=$this->getRequest()->getParam('qty1');
             $price1=$this->getRequest()->getParam('price1');
            if($price1)
            {   
                 $checkqty1=$this->getRequest()->getParam('checkqty1');
                 if($qty1>$checkqty1)
                {
        
                    $this->messageManager->addWarning('Quantity Are Not Available As Per Your Need');
                    $this->_redirect("coreoverride/index/index");
                }
              else
              { 
                $pid1=$this->getRequest()->getParam('pid1');
                
                $resultPage = $this->resultPageFactory->create();
                $params = array(
                    'form_key' => $this->formKey->getFormKey(),
                    'product' =>$pid1,//product Id
                    'qty'   =>$qty1,//quantity of product
                    'price' =>$price1 //product price
                );
                // echo $pid.$qty.$price;
                // exit();
                 $this->_redirect("checkout/cart/add/form_key/", $params);
                 /** @var \Magento\Framework\View\Result\Page $resultPage */
                 return $resultPage;
               }
             }
        else
        {
                   $this->messageManager->addWarning('Please Fill All The Values it Should Not Be 0 or Empty');
                    $this->_redirect("coreoverride/index/index");
        }
    }
       
// Adding Value of Cart three
        if($addtocart2)
        { 
             $sku2 = $this->getRequest()->getParam('sku2');
             $qty2=$this->getRequest()->getParam('qty2');
             $price2=$this->getRequest()->getParam('price2');
            if($price2)
            {   
                 $checkqty2=$this->getRequest()->getParam('checkqty2');
                 if($qty2>$checkqty2)
                {
        
                    $this->messageManager->addWarning('Quantity Are Not Available As Per Your Need');
                    $this->_redirect("coreoverride/index/index");

                   }
              else
              { 
                $pid2=$this->getRequest()->getParam('pid2');
                
                $resultPage = $this->resultPageFactory->create();
                $params = array(
                    'form_key' => $this->formKey->getFormKey(),
                    'product' =>$pid2,//product Id
                    'qty'   =>$qty2,//quantity of product
                    'price' =>$price2 //product price
                );
                // echo $pid.$qty.$price;
                // exit();
                 $this->_redirect("checkout/cart/add/form_key/", $params);
                 /** @var \Magento\Framework\View\Result\Page $resultPage */
                 return $resultPage;
               }
            }
         else
         {
                    $this->messageManager->addWarning('Please Fill All The Values it Should Not Be 0 or Empty');
                    $this->_redirect("coreoverride/index/index");
         }
    }
  }
}
 