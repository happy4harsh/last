<?php	
namespace CP\Coreoverride\Controller\Index;
use Magento\Catalog\Api\ProductRepositoryInterface;
class Post extends \Magento\Framework\App\Action\Action
{
    protected $resultPageFactory;
    protected $productRepository;
    protected $_stockItemRepository;
    protected $productModel;
    protected $formKey;



    public function __construct(\Magento\Framework\App\Action\Context $context,
    \Magento\Catalog\Model\Product $productModel,
     \Magento\Framework\Data\Form\FormKey $formKey,
     \Magento\Framework\View\Result\PageFactory $resultPageFactory,
     ProductRepositoryInterface $productRepository)     {

        $this->productRepository = $productRepository;
        $this->resultPageFactory = $resultPageFactory;
        $this->productFactory = $productModel;
        $this->formKey = $formKey;

        parent::__construct($context);
    }
    public function execute()
    {
       
                //print_r($this->getRequest()->getParams());die;

                $sku = $this->getRequest()->getParam('sku');
                //$pid=$this->productFactory->getIdBySku($sku);
                
                 $product = $this->productRepository->get($sku);
                 //$product =$this->productFactory->getIdBySku($sku);
                  // echo "<pre>"; var_dump($product);
                  // die(); 
                         echo json_encode($product->toArray());
                        die();
                    // $params = array(
                    //     'form_key' => $this->formKey->getFormKey(),
                    //     'product' =>1,//product Id
                    //     'qty'   =>1,//quantity of product
                    //     'price' =>80 //product price
                    // );
                    // $this->_redirect("checkout/cart/add/form_key/", $params);
     
                    // $product= $this->productRepository->getById($sku);
                    //echo "<pre>"; var_dump($product);
                    //echo json_encode($pid->toArray());
                   
            
                    $resultPage = $this->resultPageFactory->create();
                    // $post = $this->getRequest()->getPostValue();
                    // echo $sku= $post["sku"];
                    return $resultPage;
    }
}                   