<?php
namespace CP\Override\Block;
 
class Mydownload extends \Magento\Framework\View\Element\Template
{
    public function getMyDownloadLink()
    {





		echo __('<a href="#"> 1. Price sheet</a>'."</br>");
    	echo __('<a href="#"> 2. Customer feedback from</a>'."</br>");
    	echo __('<a href="#"> 3. Monogram PDF</a>'."</br>");
    	echo __('<a href="#"> 4. Monogram manual form</a>'."</br>");
    	echo __('<a href="#"> 5. Credit card authorization form</a>'."</br>");
    	echo __('<a href="#"> 6. Screen print & embroidery logo prices</a>'."</br>");
    	echo __('<a href="#"> 7. Custom order form</a>'."</br>");


    	

        
    }
}



?>
            
            