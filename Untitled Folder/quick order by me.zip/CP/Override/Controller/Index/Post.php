
<?php	
namespace CP\Override\Controller\Index;
use Magento\Catalog\Api\ProductRepositoryInterface;

class Post extends \Magento\Framework\App\Action\Action
{
    protected $resultPageFactory;

    protected $productRepository;

    public function __construct(\Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        ProductRepositoryInterface $productRepository)     {

        $this->productRepository = $productRepository;
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }
    public function execute()
    {
        //print_r($this->getRequest()->getParams());die;
        echo "string"; exit();

        $sku = $this->getRequest()->getParam('sku');

        $product = $this->productRepository->get($sku);

        //echo "<pre>"; var_dump($product);
        echo json_encode($product->toArray());

        die;

        $resultPage = $this->resultPageFactory->create();
        // $post = $this->getRequest()->getPostValue();
        // echo $sku= $post["sku"];
        return $resultPage;
    }
}                   
 
