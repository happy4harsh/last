<?php
/**
     * Add product to shopping cart action
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    public function execute()
    {
        echo "string"; exit();

        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        $request = $this->getRequest()->getParams();
        try {


            $sku_list = [];

            foreach($request as $k => $v){
                if (strpos($k, 'qty_') !== false) {
                    $sku = explode('_',$k);
                    if($v !="" || $v !=0)
                        $sku_list[$sku[1]] = $v;
                }
            }

            $product = $this->_productFactory->create();

            foreach($sku_list as $k => $v){

                $data = $product->loadByAttribute('sku',$k);
                $product = $this->_initProduct1($data->getId());

                /**
                 * Check product availability
                 */
                if (!$product) {
                    return $this->goBack();
                }

                $requests = array('product' => $product->getId(),'qty' => $v);
                $_product = $this->productRepository->getById($product->getId());
                $qty = $v;

                if($_product->getTypeId() == "bundle"){

                    //
                    $productTypeInstance = $product->getTypeInstance();
                    $requiredChildrenIds = $productTypeInstance->getChildrenIds($_product->getId(), true);

                    $par = array('product' => $product->getId(),
                        "bundle_options" => array(),
                        'qty' => $v);
                    $magento = [];
                    foreach($requiredChildrenIds as $child){
                        $i =0;
                        foreach($child as $k => $v){
                            $i++;
                            $prod = $this->productRepository->getById($v);
                            $isSaleable = $prod->isSalable();
                            if($isSaleable){
                                $magento[$v] = "$i";
                            }else{
                                $message = __('No stock for this Item',$_product->getName());
                                $this->messageManager->addErrorMessage($message);
                                return $this->goBack(null, $product);
                            }
                        }

                    }
                    $par = array(
                        'product' => $product->getId(),
                        'bundle_options' => array(  1 => $magento),
                        'qty' => $qty
                    );

                    $this->cart->addProduct($_product,$par);

                }else{
                    $this->cart->addProduct($_product,$requests);
                }



                $message = __('You added %1 to your shopping cart.',$product->getName());
                $this->messageManager->addSuccessMessage($message);

            }

            $this->cart->save();

            return $resultRedirect->setPath('quickorder/index/index');

        }  catch (\Exception $e) {
            $this->messageManager->addException($e, __('We can\'t add this item to your shopping cart right now.'));
            $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
            return $this->goBack();
        }
    }