<?php
namespace CP\Mail\Block;
class mail extends \Magento\Framework\View\Element\Template
{
 public function getMail()
 {
 	echo "Mail Gone";
 }	
}
