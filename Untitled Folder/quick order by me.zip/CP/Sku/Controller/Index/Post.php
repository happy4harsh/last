<?php	
namespace CP\Sku\Controller\Index;
use Magento\Catalog\Api\ProductRepositoryInterface;
class Post extends \Magento\Framework\App\Action\Action
{
    protected $resultPageFactory;

    protected $productRepository;

    public function __construct(\Magento\Framework\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        ProductRepositoryInterface $productRepository)     {

        $this->productRepository = $productRepository;
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }
    public function execute()
    {
        //print_r($this->getRequest()->getParams());die;

        $sku = $this->getRequest()->getParam('sku');
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $_product = $objectManager->create('Magento\Catalog\Model\Product');
        $_product->load($_product->getIdBySku($sku));

        //$product = $this->productRepository->get($sku);
        // echo $_product->getId();
        // die();
        //echo "<pre>"; var_dump($product);
        return json_encode($_product->toArray());

        die;

        $resultPage = $this->resultPageFactory->create();
        // $post = $this->getRequest()->getPostValue();
        // echo $sku= $post["sku"];
        return $resultPage;
    }
}  