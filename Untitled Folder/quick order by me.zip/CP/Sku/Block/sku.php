<?php
namespace CP\Sku\Block;

use Magento\Framework\View\Element\Template;
use Magento\Catalog\Api\CategoryRepositoryInterface;
// use Magento\Catalog\Model\Product;
// use Magento\Eav\Model\Entity\Collection\AbstractCollection;
// use Magento\Framework\Exception\NoSuchEntityException;
// use Magento\Framework\DataObject\IdentityInterface;

class Newarrival extends \Magento\Catalog\Block\Product\ListProduct{

    protected $_productCollectionFactory;
    protected $_coreRegistry = null;

     public function __construct(
       \Magento\Catalog\Block\Product\Context $context, \Magento\Framework\Data\Helper\PostHelper $postDataHelper, \Magento\Catalog\Model\Layer\Resolver $layerResolver, CategoryRepositoryInterface $categoryRepository,\Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollection, \Magento\Framework\Url\Helper\Data $urlHelper, \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,\Magento\Catalog\Model\ResourceModel\Product\Collection $collection, \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, \Magento\Catalog\Helper\Image $imageHelper, array $data = []
    ) {
        $this->imageBuilder = $context->getImageBuilder();
        $this->_catalogLayer = $layerResolver->get();
        $this->_postDataHelper = $postDataHelper;
        $this->_productCollectionFactory = $productCollectionFactory;
        $this->categoryRepository = $categoryRepository;
        $this->urlHelper = $urlHelper;
        $this->_collection = $collection;
        $this->_imageHelper = $imageHelper;
        $this->_scopeConfig = $scopeConfig;
        parent::__construct($context, $postDataHelper, $layerResolver, $categoryRepository, $urlHelper, $data);

        $this->pageConfig->getTitle()->set(__($this->getPageTitle()));
    }
    
    public function getProductCollection(){
        if($this->getMode()=="grid"){
            $limit = $this->_scopeConfig->getValue('catalog/frontend/grid_per_page', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        } else {
             $limit = $this->_scopeConfig->getValue('catalog/frontend/list_per_page', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        }
       
        $page=($this->getRequest()->getParam('p'))? $this->getRequest()->getParam('p') : 1;
        $pageSize=($this->getRequest()->getParam('limit'))? $this->getRequest()->getParam('limit') : $limit; 
        $collection = $this->_productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->addAttributeToFilter('newarrival', 1 );
        $collection->setPageSize($pageSize);
        $collection->setCurPage($page);
        return $collection;
    }

    public function getLoadedProductCollection()
    {
        return $this->getProductCollection();
    }
    
    
    
   
   
}