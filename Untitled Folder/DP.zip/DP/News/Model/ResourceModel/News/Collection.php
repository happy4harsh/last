<?php
  
namespace DP\News\Model\ResourceModel\News;
  
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
  
class Collection extends AbstractCollection
{
    /**
     * Define model & resource model
     */
    protected $_idFieldName = 'id';
    protected function _construct()
    {
        $this->_init(
            'DP\News\Model\News',
            'DP\News\Model\ResourceModel\News'
        );
    }
}
