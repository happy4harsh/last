<?php
  
namespace DP\News\Model;
  
use Magento\Framework\Model\AbstractModel;
  
class News extends AbstractModel
{
    /**
     * Define resource model
     */
    protected function _construct()
    {
        $this->_init('DP\News\Model\ResourceModel\News');
    }
}
