<?php
namespace DP\News\Controller\Adminhtml\Index;
use Magento\Framework\App\Action\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends \Magento\Backend\App\Action
{
    protected $resultPageFactory;

    /**
    * @param Context $context
    * @param PageFactory $resultPageFactory
    */
    public function __construct(Context $context,PageFactory $resultPageFactory) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }
 

    protected function initPage($resultPage)
    {
        $resultPage->setActiveMenu('DP_News::post')
            ->addBreadcrumb(__('Show News'), __('Show News'))
            ->addBreadcrumb(__('Show News'), __(''));
        return $resultPage;
    }

    public function execute(){
        //echo "hello";
        $resultPage = $this->resultPageFactory->create();
        $this->initPage($resultPage)->getConfig()->getTitle()->prepend(__('News'));
        return $resultPage;
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('DP_News::newsdp');
    }
}
