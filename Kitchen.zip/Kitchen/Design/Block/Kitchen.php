<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Kitchen\Design\Block;

use Magento\Framework\View\Element\Template;

/**
 * Main contact form block
 */
class Kitchen extends Template{

  //   protected $_newsmoduleFactory; 

	 // public function __construct(Template\Context $context,
  //       \CP\Newsmodule\Model\NewsmoduleFactory $newsFactory,
  //       \Magento\Framework\App\Request\Http $request,
  //        array $data = [])
  //   {
  //       $this->_newsmoduleFactory = $newsFactory;
  //       $this->request = $request;
  //       parent::__construct($context, $data);
  //   } 
  public function getDate()
  {
    return $get_date=array("1 to 2 weeks","2 to 4 weeks","1 to 3 months","3 to 6 months","6 to 12 months");
  }
	public function getFormAction(){
        if($this->getRequest()->getParam('id')){
            return $this->getUrl('kitchen/index/save/id/'.$this->getRequest()->getParam('id'));    
        } else {
            return $this->getUrl('kitchen/index/save');
        }
        return $this->getUrl('kitchen/index/save');
	}
	public function getCollection()
    {
        // $id=$this->getRequest()->getParam('id') ;
        // return $this->_newsmoduleFactory->create()->load($id); 
    }
    public function getnewscollection()
    {
        // $data=$this->_newsmoduleFactory->create()->getCollection();
        // return $data;
    }
    public function getDeleteUrl($id) {
        return $this->getUrl('kitchen/index/delete', array('id' => $id));
    }
    public function getEditUrl($id){
        return $this->getUrl('kitchen/index/edit', array('id' => $id));
    }
    public function getNewUrl(){
        return $this->getUrl('newsmodule/index/new');
    }
}