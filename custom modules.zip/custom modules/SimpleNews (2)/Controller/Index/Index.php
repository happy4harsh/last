<?php

namespace CP\SimpleNews\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use CP\SimpleNews\Model\SimpleNews2Factory;
use CP\SimpleNews\Model\SimpleNewsFactory;

class Index extends Action
{
    /**
     * @var \CP\SimpleNews\Model\FriendFactory
     */
    protected $_modelSimpleNews2Factory;
    protected $_modelSimpleNewsFactory;

    /**
     * @param Context $context
     * @param FriendFactory $modelFriendFactory
     */
    public function __construct(
        Context $context,
        SimpleNews2Factory $modelSimpleNews2Factory,
        SimpleNewsFactory $modelSimpleNewsFactory

    ) {
        parent::__construct($context);
        $this->_modelSimpleNews2Factory = $modelSimpleNews2Factory;
        $this->_modelSimpleNewsFactory = $modelSimpleNewsFactory;
    }

    public function execute()
    {
            
        /**
         * When Magento get your model, it will generate a Factory class
         * for your model at var/generaton folder and we can get your
         * model by this way
         */
        
        

        // Load the First table data simplenews2 with id 13
        $SimpleNews2Model = $this->_modelSimpleNews2Factory->create();
        $SimpleNews2 = $SimpleNews2Model->load(12);
        if($SimpleNews2){
                        echo $SimpleNews2->getName() . " found with Id 1";
            echo "<hr/>";
        }

        // Get friend collection
        $SimpleNews2Collection = $SimpleNews2Model->getCollection();
        // Load all data of collection
        foreach($SimpleNews2Collection as $SimpleNews2){
            echo $SimpleNews2->getName() . " , " . $SimpleNews2->getFriendType() . "<br/>";
        }



        // Load the First table data simplenews with id 20
        $SimpleNewsModel = $this->_modelSimpleNewsFactory->create();
        $SimpleNews = $SimpleNewsModel->load(20);
        if($SimpleNews){
                        echo $SimpleNews->getName() . " found with Id 1";
            echo "<hr/>";
        }

        // Get friend collection
        $SimpleNewsCollection = $SimpleNewsModel->getCollection();
        // Load all data of collection
        foreach($SimpleNewsCollection as $SimpleNews){
            echo $SimpleNews->getName() . " , " . $SimpleNews->getFriendType() . "<br/>";
        }
    }
}