<?php
namespace CP\SimpleNews\Model\ResourceModel\SimpleNews2;



class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'id';
    protected function _construct()
    {
		
		$this->_init('CP\SimpleNews\Model\SimpleNews2','CP\SimpleNews\Model\ResourceModel\SimpleNews2');
    }
}