<?php
namespace Inchoo\Helloworld\Block;
 
class Helloworld extends \Magento\Framework\View\Element\Template
{
    public function getHelloWorldTxt()
    {
        return 'Hello world!';
 }
 // public function getCollection(){
 //    $post = $this->getRequest()->getPostValue(); 
 //    return;
 // }
}
