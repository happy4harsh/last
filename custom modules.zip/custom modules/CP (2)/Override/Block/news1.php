<?php
namespace CP\Override\Block;
  
class news1 extends \Magento\Framework\View\Element\Template
{
    public function getFormAction()
    {
    	
        return $this->getUrl('newsmodule/index/post', ['_secure' => true]);
    }
}