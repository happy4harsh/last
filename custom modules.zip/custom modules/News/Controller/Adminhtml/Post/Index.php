<?php

namespace CP\News\Controller\Adminhtml\Post;

class Index extends \CP\News\Controller\Adminhtml\Index
{
    protected $resultPageFactory;
 
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context, $coreRegistry);
    }
 
    public function execute()
    {
 
        $resultPage = $this->resultPageFactory->create();
         // $this->initPage($resultPage)->getConfig()->getTitle()->prepend(__('News'));
        return $resultPage;
    }
}
