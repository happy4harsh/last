<?php

namespace CP\News\Controller\Adminhtml\Post;

use Magento\Backend\App\Action;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;

class Edit extends Action
{
    const ADMIN_RESOURCE = 'CP_News::save';
    protected $_coreRegistry = null;
    protected $resultPageFactory;

    public function __construct(Action\Context $context, PageFactory $resultPageFactory, Registry $registry)
    {
        $this->_coreRegistry = $registry;
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed(self::ADMIN_RESOURCE);
    }

    protected function _initAction()
    {
        $resultPage = $this->resultPageFactory->create();
        // $resultPage->setActiveMenu('CP_News::main')
            // ->addBreadcrumb(__('News'), __('News'))
            // ->addBreadcrumb(__('Manage Events'), __('Manage Events'));
        return $resultPage;
    }

    public function execute()
    {
        // echo "string";exit();
        $id = $this->getRequest()->getParam('id');
        $model = $this->_objectManager->create('CP\News\Model\News');
        if ($id) {
            $model->load($id);
            if (!$model->getId()) {
                $this->messageManager->addError(__('This Event no longer exists.'));
                /** \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
                $resultRedirect = $this->resultRedirectFactory->create();

                return $resultRedirect->setPath('*/*/');
            }
        }
        
        $data = $this->_objectManager->get('Magento\Backend\Model\Session')->getFormData(true);
        if (!empty($data)) {
            $model->setData($data);
        }

        $this->_coreRegistry->register('news_item', $model);

        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_initAction();
        $resultPage->addBreadcrumb(
            $id ? __('Edit Grid') : __('New Grid'),
            $id ? __('Edit Grid') : __('New Grid')
        );
        $resultPage->getConfig()->getTitle()->prepend(__('News Edit'));

        return $resultPage;
    }
}