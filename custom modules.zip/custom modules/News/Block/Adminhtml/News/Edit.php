<?php 
namespace CP\News\Block\Adminhtml\News;
 
class Edit extends \Magento\Backend\Block\Widget\Form\Container
{
    protected $_coreRegistry = null;
 
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Magento\Framework\Registry $registry,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }
 
    protected function _construct()
    {
        $this->_objectId = 'id';
        $this->_blockGroup = 'CP_News';
        $this->_controller = 'adminhtml_news';
 
        parent::_construct();
 
        $this->buttonList->update('save', 'label', __('Save News'));
        $this->buttonList->update('delete', 'label', __('Delete News'));
 
        $this->buttonList->add(
            'saveandcontinue',
            [
                'label' => __('Save and Continue Edit'),
                'class' => 'save',
                'data_attribute' => [
                    'mage-init' => ['button' => ['news' => 'saveAndContinueEdit', 'target' => '#edit_form']],
                ]
            ],
            -100
        );
 
    }
 
 
    public function getHeaderText()
    {
        if ($this->_coreRegistry->registry('news_item')->getId()) {
            return __("Edit Block '%1'", $this->escapeHtml($this->_coreRegistry->registry('news_item')->getName()));
        } else {
            return __('New News');
        }
    }
}