<?php
namespace CP\News\Block;

class Form extends \Magento\Framework\View\Element\Template
{
    public function getHelloWorldTxt()
     	{
         	$post= $this->getRequest()->getPostValue();  	
        	return $post;
     	}
}